document.addEventListener("DOMContentLoaded", () => {
    console.log("SPCA Website Loaded");
});
